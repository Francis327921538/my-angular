/**
 * Created by francis.zhang01 on 12/7/2016.
 */

var myDirectives = angular.module('MyDirectives', []);

myDirectives.directive('myHead', function () {
    return {
        restrict: 'AE',
        templateUrl: 'tpls/my-head.html'
    }
});
myDirectives.directive('myListGroup', function () {
    return {
        restrict: 'AE',
        templateUrl: 'tpls/my-list-group.html'
    }
});
myDirectives.directive('myJumbotron', function () {
    return {
        restrict: 'AE',
        templateUrl: 'tpls/my-jumbotron.html'
    }
});

//
// myDirectives.directive('myAccordion1', function() {
//     return {
//         restrict : 'EA',
//         replace : true,
//         transclude : true,
//         template : '<div ng-transclude></div>',
//         controller : function() {
//             var expanders = [];
//             this.gotOpened = function(selectedExpander) {
//                 angular.forEach(expanders, function(expander) {
//                     if (selectedExpander != expander) {
//                         expander.showMe = false;
//                     }
//                 });
//             }
//             this.addExpander = function(expander) {
//                 expanders.push(expander);
//             }
//         }
//     }
// });
//
// myDirectives.directive('myExpander', function() {
//     return {
//         restrict : 'EA',
//         replace : true,
//         transclude : true,
//         require : '^?myAccordion1',
//         scope : {
//             title : '=expanderTitle'
//         },
//         templateUrl : 'tpls/expander.html',
//         link : function(scope, element, attrs, accordionController) {
//             scope.showMe = false;
//             accordionController.addExpander(scope);
//             scope.toggle = function toggle() {
//                 scope.showMe = !scope.showMe;
//                 accordionController.gotOpened(scope);
//             }
//         }
//     }
// });

myDirectives.directive('myCalender', function () {
    return {
        restrict: 'AE',
        templateUrl: 'tpls/my-calender.html'
    }
});

myDirectives.directive('myAccordion', function () {
    return {
        restrict: 'AE',
        templateUrl: 'tpls/my-accordion.html'
    }
});

myDirectives.directive('myCarousel', function () {
    return {
        restrict: 'AE',
        templateUrl: 'tpls/my-carousel.html'
    }
});

myDirectives.directive('myTabs', function () {
    return {
        restrict: 'AE',
        templateUrl: 'tpls/my-tabs.html'
    }
});

myDirectives.directive('myRating', function () {
    return {
        restrict: 'AE',
        templateUrl: 'tpls/my-rating.html'
    }
});

myDirectives.directive('myPopover', function () {
    return {
        restrict: 'AE',
        templateUrl: 'tpls/my-popover.html'
    }
});

myDirectives.directive('myProgress', function () {
    return {
        restrict: 'AE',
        templateUrl: 'tpls/my-progress.html'
    }
});

myDirectives.directive('myDropdown', function () {
    return {
        restrict: 'AE',
        templateUrl: 'tpls/my-dropdown.html'
    }
});

myDirectives.directive('myModal', function () {
    return {
        restrict: 'AE',
        templateUrl: 'tpls/my-modal.html'
    }
});
