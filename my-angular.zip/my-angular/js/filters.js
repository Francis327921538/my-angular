/**
 * Created by francis.zhang01 on 12/7/2016.
 */

var myFilters = angular.module('MyFilters', []);

myFilters.filter('to_trusted', ['$sce', function ($sce) {
    return function (text) {
        return $sce.trustAsHtml(text);
    };
}]);