/**
 * Created by francis.zhang01 on 12/7/2016.
 */

var indexApp = angular.module('IndexApp', ['ngTouch', 'ui.grid', 'ui.grid.pagination', 'ui.router', 'ui.bootstrap', 'ngAnimate', 'MyControllers', 'MyDirectives', 'MyFilters']);

indexApp.config(function ($stateProvider,
                          $urlRouterProvider) {
    $urlRouterProvider.otherwise('/home/home_1');
    $stateProvider
        .state('home',{
            url: '/home',
            views: {
                '': {
                    templateUrl: 'modules/home//home.html'
                },
                'listCtrl@home': {
                    templateUrl: 'modules/home/home_modules/listCtrl.html'
                }
            }
        })
        .state('home.h1',{
            url: '/home_1',
            templateUrl: 'modules/home/home_modules/home_1.html'
        })
        .state('home.h2',{
            url: '/home_2',
            templateUrl: 'modules/home/home_modules/home_2.html'
        })
        .state('home.h3',{
            url: '/home_3',
            templateUrl: 'modules/home/home_modules/home_3.html'
        })
        .state('home.h4',{
            url: '/home_4',
            templateUrl: 'modules/home/home_modules/home_4.html'
        })
        .state('p1',{
            url:'/1',
            templateUrl:'modules/module1/1.html'
        })
        .state('p2',{
            url:'/2',
            templateUrl:'modules/module2/2.html'
        })
        .state('p3',{
            url:'/3',
            templateUrl:'modules/module3/3.html'
        });

})
/*
indexApp.config(function ($routeProvider) {
    $routeProvider.
    when('/', {
            templateUrl: 'modules/home/home.html'
    }).
    when('/home', {
            templateUrl: 'modules/home/home.html'
    }).
    when('/1', {
            templateUrl: 'modules/module1/1.html'
    }).
    when('/2', {
            templateUrl: 'modules/module2/2.html'
    }).
    when('/3', {
            templateUrl: 'modules/module3/3.html'
    }).
    otherwise({
        redirectTo: 'home'
    });

});*/
